#Dependencies:
#Python 3.7 32 bit
#PyVisa 1.7
#
#JAC: 03/31/2020
#-Added \n to write and read terminations
 
import visa
import time # for sleep
import binascii
 
def main():
    rm = visa.ResourceManager()
    instadd = 'USB0::0xF4EC::0x1410::SPD1XDAD1R0011::INSTR'
    inst = rm.open_resource(instadd)
    inst.write_termination='\n'
    inst.read_termination='\n'
    print (rm.list_resources())
    time.sleep(0.04)
    inst.write('OUTP CH1,ON')
    time.sleep(2)
    inst.write('OUTP CH1,OFF')
    time.sleep(2)
    inst.write('*IDN?')
    #print ("here")
    time.sleep(1)
    qStr = inst.read()
    print (str(qStr))
    inst.close()
    
if __name__ == '__main__':
    main()
